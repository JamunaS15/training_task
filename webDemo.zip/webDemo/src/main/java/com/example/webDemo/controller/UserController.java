package com.example.webDemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.webDemo.model.User;
import com.example.webDemo.repository.UserRepository;

@RestController
public class UserController {
	
	@Autowired
	UserRepository userRepo;
	
	@GetMapping("/")
	public String getWelcome()
	{
		return "welcome user";
	}
	
	@PostMapping("/addUser")
	public User addUser(@RequestBody User user) {
		userRepo.save(user);
		return user;
	}
	
	@GetMapping("getAllUsers")
	public List<User> getUsers(){
		return userRepo.findAll();
	}
}
